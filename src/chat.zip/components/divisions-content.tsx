
"use client";

import { useState } from "react";
import { divisions } from "../data/site-content";

const divisionDetails: Record<
  string,
  {
    hod: string;
    overview: string;
    history: string;
    work: string[];
    facilities: string;
  }
> = {
  "Cyber Forensics": {
    hod: "Smt. Maheshwari",
    overview:
      "Digital forensics concerns the scientific examination of digital devices and electronic evidence to help establish relevant facts in an investigation. The exact scope depends on the evidence received and the laboratory's confirmed capabilities.",
    history:
      "The establishment history and milestones of the Digital Forensics section need confirmation from CFSL Hyderabad's official records.",
    work: [
      "Examination of digital devices and electronic evidence, subject to the laboratory's approved scope.",
      "Identification and analysis of relevant digital artefacts.",
      "Documentation of examination procedures and findings.",
      "Preparation of scientific findings for the referring authority.",
    ],
    facilities:
      "Specific forensic tools, supported devices, laboratory facilities and examination capabilities should be added after verification.",
  },
  "Physical Sciences": {
    hod: "Smt. Maheshwari",
    overview:
      "Physical-science examinations apply scientific methods to relevant physical evidence. This section is presented as a general overview; the laboratory's precise organisational structure and scope should be confirmed.",
    history:
      "Department establishment dates and historical milestones have not yet been verified.",
    work: [
      "Scientific examination of relevant physical evidence within the approved scope.",
      "Application of suitable measurement, comparison and analytical methods.",
      "Recording observations and examination results.",
      "Preparation of technical findings for the referring authority.",
    ],
    facilities:
      "The specific facilities and instruments used by CFSL Hyderabad need official confirmation.",
  },
  "Ballistics": {
    hod: "Smt. Maheshwari",
    overview:
      "Forensic ballistics examines firearms-related evidence using scientific methods. The exact examinations offered by CFSL Hyderabad should be confirmed before publishing a definitive service list.",
    history:
      "The department's history and development milestones remain to be confirmed.",
    work: [
      "Scientific examination of firearms-related evidence, where within the approved scope.",
      "Examination of relevant ammunition and associated components.",
      "Comparison and interpretation of suitable ballistic evidence.",
      "Documentation of findings and preparation of forensic reports.",
    ],
    facilities:
      "Specific equipment, comparison facilities and examination capabilities require confirmation from the laboratory.",
  },
  "Biological Sciences": {
    hod: "To be confirmed",
    overview:
      "Biological forensic examination applies scientific methods to biological material that may be relevant to an investigation.",
    history:
      "The establishment history and milestones of this section need official confirmation.",
    work: [
      "Examination of biological material within the laboratory's approved scope.",
      "Scientific assessment and documentation of relevant findings.",
      "Interpretation of results in the context of the questions referred.",
      "Preparation of reports for the referring authority.",
    ],
    facilities:
      "Confirm whether and which biological, serological or DNA examination facilities are available at CFSL Hyderabad.",
  },
  "Chemical Sciences": {
    hod: "To be confirmed",
    overview:
      "Chemical forensic examination uses analytical methods to identify or characterise substances and residues relevant to investigations.",
    history:
      "Official establishment dates and departmental milestones have not yet been confirmed.",
    work: [
      "Chemical analysis of submitted samples within the approved scope.",
      "Identification or characterisation of relevant substances and residues.",
      "Use of suitable analytical methods to support examination findings.",
      "Documentation and reporting of analytical results.",
    ],
    facilities:
      "Instrument names, analytical capabilities and the categories of samples accepted must be confirmed from official sources.",
  },
  "Questioned Documents": {
    hod: "To be confirmed",
    overview:
      "Questioned-document examination can involve the scientific assessment of documents whose authorship, authenticity or features are disputed.",
    history:
      "The history and organisational position of this section require official confirmation.",
    work: [
      "Examination of questioned documents within the approved scope.",
      "Comparison of relevant handwriting or signatures, where applicable.",
      "Assessment of suspected alterations or other document features, where supported.",
      "Recording observations and reporting examination findings.",
    ],
    facilities:
      "Specific document-examination instruments and the services available locally need confirmation.",
  },
  "Research & Development": {
    hod: "To be confirmed",
    overview:
      "Research and development can support improvements in forensic methods, scientific knowledge, training and laboratory practice.",
    history:
      "The section's establishment and documented milestones have not yet been verified.",
    work: [
      "Research activities relevant to forensic science, where undertaken.",
      "Evaluation or improvement of scientific examination methods.",
      "Technical knowledge sharing and training, where officially supported.",
      "Scientific collaboration and development activities, where applicable.",
    ],
    facilities:
      "Specific research programmes, collaborations and dedicated facilities should be added only after verification.",
  },
};

export default function DivisionsContent() {
  const [selected, setSelected] = useState("Cyber Forensics");

  const current =
    divisionDetails[selected] ?? {
      hod: "To be confirmed",
      overview: "Official information for this division is being compiled.",
      history: "Department history needs official confirmation.",
      work: [
        "Add verified areas of expertise.",
        "Add the confirmed examination scope.",
        "Add official reporting and submission guidance.",
      ],
      facilities: "Facilities and instruments need official confirmation.",
    };

  return (
    <section className="section page-content divisions-page-content">
      <div className="site-container page-content-grid divisions-page-grid">
        <aside
          className="side-nav division-side-nav"
          aria-label="Scientific divisions"
        >
          <span className="side-nav-heading">On this page</span>

          {divisions.map((item) => (
            <button
              key={item.title}
              type="button"
              className={`division-selector ${
                selected === item.title ? "active" : ""
              }`}
              aria-current={selected === item.title ? "page" : undefined}
              onClick={() => setSelected(item.title)}
            >
              {item.title}
            </button>
          ))}

          <button
            type="button"
            className={`division-selector ${
              selected === "Ballistics" ? "active" : ""
            }`}
            aria-current={selected === "Ballistics" ? "page" : undefined}
            onClick={() => setSelected("Ballistics")}
          >
            Ballistics
          </button>
        </aside>

        <article className="page-article divisions-article">
          <span className="section-kicker">
            CFSL Hyderabad · Scientific division
          </span>

          <h2>{selected}</h2>
          <p>{current.overview}</p>

          <div className="division-detail-block">
            <h3>Head of Department</h3>
            <p>{current.hod}</p>
            {current.hod === "Smt. Maheshwari" && (
              <p className="division-note">
                Officer information is based on the details provided and
                should be checked against the current official directory.
              </p>
            )}
          </div>

          <div className="division-detail-block">
            <h3>Department history</h3>
            <p>{current.history}</p>
          </div>

          <div className="division-detail-block">
            <h3>Areas of work</h3>
            <ul className="article-list">
              {current.work.map((item) => (
                <li key={item}>{item}</li>
              ))}
            </ul>
          </div>

          <div className="division-detail-block">
            <h3>Facilities and instruments</h3>
            <p>{current.facilities}</p>
          </div>

          <p className="division-source-note">
            This page is a developing information directory. Confirm the
            division's official name, responsibilities, officer details and
            facilities before treating this information as an official
            laboratory statement.
          </p>
        </article>
      </div>
    </section>
  );
}
