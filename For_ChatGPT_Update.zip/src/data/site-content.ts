export type NavItem = { label: string; href: string; children?: { label: string; href: string }[] };

// Navigation labels are based on the supplied reference screenshots.
// All links use the existing frontend routes; official content can be connected later.
export const navigation: NavItem[] = [
  { label: "Home", href: "/" },
  { label: "Overview", href: "/about" },
  {
    label: "About Us",
    href: "/about",
    children: [
      { label: "Citizen Charter", href: "/about" },
      { label: "Greetings From The Principal Director", href: "/profile" },
      { label: "Greetings From The Director", href: "/profile" },
      { label: "Acknowledgement", href: "/about" },
      { label: "Prominent Cases", href: "/about" },
    ],
  },
  {
    label: "Divisions",
    href: "/divisions",
    children: [
      { label: "Biological Sciences", href: "/divisions" },
      { label: "Chemical Sciences", href: "/divisions" },
      { label: "Cyber Forensic Division", href: "/divisions" },
      { label: "Documents Division", href: "/divisions" },
      { label: "Forensic Psychology Division", href: "/divisions" },
      { label: "Physical Sciences", href: "/divisions" },
      { label: "Research & Development Activities", href: "/divisions" },
      { label: "Quality Management Division", href: "/divisions" },
      { label: "Scene of Crime Investigation", href: "/divisions" },
    ],
  },
  {
    label: "Services",
    href: "/services",
    children: [
      { label: "Services Overview", href: "/services" },
      { label: "Case Forwarding Checklist", href: "/services/case-forwarding-checklist" },
    ],
  },
  {
    label: "Notice Board",
    href: "/notices",
    children: [
      { label: "What's New", href: "/notices" },
      { label: "Latest News", href: "/notices" },
      { label: "Vacancy", href: "/notices" },
      { label: "Related Links", href: "/notices" },
      { label: "Important Links", href: "/notices" },
      { label: "Vigilance Complaint Information Management System (VCIMS)", href: "/notices" },
      { label: "Delhi Govt. Website", href: "/notices" },
      { label: "Recruitment Rules", href: "/notices" },
    ],
  },
  { label: "RTI", href: "/rti" },
  { label: "Contact Us", href: "/contact" },
];

export const quickLinks = [
  { icon: "⌕", title: "Public Notices", subtitle: "Updates and announcements", href: "/notices" },
  { icon: "⌘", title: "Forensic Divisions", subtitle: "Explore areas of expertise", href: "/divisions" },
  { icon: "▤", title: "Public Information", subtitle: "Resources and RTI", href: "/rti" },
  { icon: "✉", title: "Contact Laboratory", subtitle: "Find contact information", href: "/contact" },
];

export const divisions = [
  { icon: "⌘", title: "Cyber Forensics", description: "Sample overview of digital evidence examination and related forensic capabilities.", href: "/divisions" },
  { icon: "◈", title: "Physical Sciences", description: "A placeholder for relevant physical-science disciplines and their scope of work.", href: "/divisions" },
  { icon: "❋", title: "Biological Sciences", description: "A placeholder for biological examination services and scientific disciplines.", href: "/divisions" },
  { icon: "⚗", title: "Chemical Sciences", description: "A placeholder for chemical analysis and associated laboratory capabilities.", href: "/divisions" },
  { icon: "◎", title: "Questioned Documents", description: "A placeholder for document examination information and related services.", href: "/divisions" },
  { icon: "⌁", title: "Research & Development", description: "A placeholder for research, training, collaboration and development activities.", href: "/divisions" },
];

export const notices = [
  { day: "27", month: "OCT", type: "Sample notice", title: "Demonstration notice — replace with an approved laboratory announcement", summary: "This entry is illustrative content for layout testing only.", date: "27 October 2026" },
  { day: "22", month: "OCT", type: "Training", title: "Demonstration training update for the notices section", summary: "Use this area for verified training announcements or institutional updates.", date: "22 October 2026" },
  { day: "15", month: "OCT", type: "Public information", title: "Example public information resource listing", summary: "Replace this text and its link with the correct official document when available.", date: "15 October 2026" },
];

export const events = [
  { title: "Training and capacity building", description: "A sample item for future workshops, training programmes or academic engagement announcements." },
  { title: "Scientific updates", description: "A placeholder for verified research updates, institutional activities and public announcements." },
  { title: "Public resources", description: "A place to highlight approved resources, forms, guidelines or information for stakeholders." },
];

export const pages: Record<string, { title: string; intro: string; heading: string; paragraphs: string[]; bullets: string[] }> = {
  about: { title: "About the Laboratory", intro: "An introduction to the institution, its purpose and its role in forensic science.", heading: "Institutional overview", paragraphs: ["This page currently contains demonstration copy. Replace it with the approved institutional history, mandate, administrative details and other verified information for CFSL Hyderabad.", "The final content should explain the laboratory's role in supporting scientific examination and the justice system without making unverified claims about specific services, accreditations or statutory responsibilities."], bullets: ["Institutional history and mandate", "Scientific approach and quality principles", "Public information and stakeholder engagement"] },
  profile: { title: "Institutional Profile", intro: "A structured place for verified institutional details and leadership information.", heading: "Profile and governance", paragraphs: ["This section is a template for approved information about the laboratory, its administration and its organisational structure."], bullets: ["Official name and administrative authority", "Leadership and organisational structure", "Approved institutional milestones"] },
  divisions: { title: "Scientific Divisions", intro: "Explore the scientific disciplines and areas of expertise represented by the laboratory.", heading: "Divisions and areas of expertise", paragraphs: ["The division names shown here are illustrative navigation examples, not a verified directory of CFSL Hyderabad. Confirm the actual divisions and their remits before publication."], bullets: ["Add each confirmed division as structured data", "Provide approved descriptions and scope of work", "Add official contact or referral guidance where appropriate"] },
  services: { title: "Services", intro: "A clear directory for approved information about forensic services and stakeholder guidance.", heading: "Service information", paragraphs: ["This page is a placeholder. Populate it with verified service descriptions, eligibility or referral information, document requirements and official procedures as applicable."], bullets: ["Approved service descriptions", "Submission and referral guidance", "Applicable forms and official resources"] },
  notices: { title: "Notices & Updates", intro: "A central place for announcements, tenders, recruitment notices and public resources.", heading: "Latest notices", paragraphs: ["The notice entries currently shown on this demonstration website are sample content. They are not real official announcements and must be replaced before deployment."], bullets: ["Use a clear title and publication date", "Link directly to the approved document or notice", "Remove expired content according to the site's publishing policy"] },
  rti: { title: "Right to Information", intro: "A structured location for public information resources and official RTI details.", heading: "Public information resources", paragraphs: ["This page is a template only. Add the current, officially verified RTI disclosures, designated officers, contact details and documents after they have been confirmed."], bullets: ["Applicable proactive disclosures", "Verified officer designations and contact information", "Official RTI forms and resources"] },
  contact: { title: "Contact the Laboratory", intro: "Contact information and visitor guidance will be provided here once verified.", heading: "Contact information", paragraphs: ["The address, telephone numbers, email addresses and office hours have intentionally not been invented. Add approved public contact details before publishing this page."], bullets: ["Official postal address", "Public telephone and email contacts", "Office hours and visitor instructions"] },
};
