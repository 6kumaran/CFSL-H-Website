import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { divisions, notices, pages } from "../../data/site-content";

type Props = { params: Promise<{ slug: string }> };

export function generateStaticParams() {
  return Object.keys(pages).map(slug => ({ slug }));
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { slug } = await params;
  const page = pages[slug];
  return page ? { title: page.title, description: page.intro } : {};
}

export default async function ContentPage({ params }: Props) {
  const { slug } = await params;
  const page = pages[slug];
  if (!page) notFound();

  return <>
    <section className="page-banner"><div className="site-container page-banner-inner"><div className="breadcrumbs"><Link href="/">Home</Link><span>/</span><span>{page.title}</span></div><h1>{page.title}</h1><p>{page.intro}</p></div></section>
    <section className="section page-content"><div className="site-container page-content-grid"><aside className="side-nav" aria-label="Section navigation">{Object.entries(pages).map(([key, item]) => <Link key={key} href={`/${key}`} aria-current={key === slug ? "page" : undefined}>{item.title}</Link>)}</aside><article className="page-article"><span className="section-kicker">CFSL Hyderabad · Draft content</span><h2>{page.heading}</h2>{page.paragraphs.map(paragraph => <p key={paragraph}>{paragraph}</p>)}<ul className="article-list">{page.bullets.map(bullet => <li key={bullet}>{bullet}</li>)}</ul>
      {slug === "divisions" && <div className="card-grid" style={{ marginTop: 24 }}>{divisions.map(item => <article className="content-card" key={item.title}><span className="card-icon" aria-hidden="true">{item.icon}</span><h3>{item.title}</h3><p>{item.description}</p></article>)}</div>}
      {slug === "notices" && <ul className="article-list">{notices.map(item => <li key={item.title}><span><strong>{item.date} · {item.type}</strong><br/>{item.title}<br/><small>{item.summary}</small></span></li>)}</ul>}
    </article></div></section>
  </>;
}
